int8_t inp[]={};
int8_t wgt[]={};
int8_t res[]={};
